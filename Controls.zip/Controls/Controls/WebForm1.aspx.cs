﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Controls
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Write("submittedd");
        }

        protected void Playback_Command(object sender, CommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "Back":
                    Response.Write("back");
                    break;
                case "Pause":
                    Response.Write("pause");
                    break;
                case "Play":
                    Response.Write("play");
                    break;
                case "Forward":
                    Response.Write("forward");
                    break;
            }
        }

   
    }
}