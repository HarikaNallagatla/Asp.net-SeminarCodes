﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PageLifeCycleEvents
{
    public partial class pagedemo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // When the page is loaded 
            Response.Write("This is load events <br/>");
        }
        protected void Page_PreInit(object sender, EventArgs e)
        {
            //The first event occur when the page is initialized.Master page and the skins are assigned  in this event
            Response.Write("This is preinit events <br/>");
        }
        protected void Page_Init(object sender, EventArgs e)
        {
            //Webcontrol Properties and to set the viewstates 
            Response.Write("This is  init events <br/>");
        }
        protected void Page_PreRender(object sender, EventArgs e)
        {
            // When there is any change about to occur to the output 
            Response.Write("This is preRender events <br/>");
        }
        protected void Page_Unload(object sender, EventArgs e)
        {
            //Page is unloaded and the process are killed in the webpage
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Write("Button is clicked<br/>");
        }

       
    }
}