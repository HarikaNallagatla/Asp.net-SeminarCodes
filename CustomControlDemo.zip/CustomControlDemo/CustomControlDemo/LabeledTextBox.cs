﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CustomControlDemo
{
    [DefaultProperty("PromptText")]
    [ToolboxData(@"<{0}:LabeledTextBox runat='server' PromptText='' PromptWidth='100' />")]
    [ToolboxBitmap(typeof(LabeledTextBox), "CustomControlDemo.LabeledTextBox.bmp")]
    public class LabeledTextBox : TextBox
    {
        public string PromptText { get; set; }
        public int PromptWidth { get; set; }
        protected override void Render(HtmlTextWriter writer)
        {
            writer.Write(
           @"<span style='”display:inline-block;width:{0}px”'>{1}&nbsp;</span>", PromptWidth, PromptText);
            base.Render(writer);
        }
    }

    public class LogoControl : WebControl
    {
        public LogoControl()
        {
        }
        public string LogoUrl
        {
            get { return _logoUrl; }
            set { _logoUrl = value; }
        }
        private string _logoUrl;
        public string CompanyName
        {
            get { return _companyName; }
            set { _companyName = value; }
        }
        private string _companyName;
        protected override void Render(HtmlTextWriter writer)
        {
            writer.WriteFullBeginTag("div");
            writer.Write(@"<img src=""{0}"" /><br />", LogoUrl);
            writer.Write(CompanyName + "<br />");
            writer.WriteEndTag("div");
        }
    }
}
