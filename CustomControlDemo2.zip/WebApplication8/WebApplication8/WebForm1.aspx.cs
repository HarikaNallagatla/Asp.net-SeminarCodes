﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CustomControlDemo;


namespace WebApplication8
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Init(object sender, EventArgs e)
        {
            int width = 150;
           LabeledTextBox prompt1 = new LabeledTextBox();
            prompt1.PromptText = "Enter Name:";
            prompt1.PromptWidth = width;
            form1.Controls.Add(prompt1);
            LiteralControl br = new LiteralControl("<br />");
            form1.Controls.Add(br);
           LabeledTextBox prompt2 = new
            LabeledTextBox();
            prompt2.PromptText = "Enter Address:";
            prompt2.PromptWidth = width;
            form1.Controls.Add(prompt2);
           LogoControl logo = new LogoControl();
            logo.CompanyName = "abc";
            logo.LogoUrl = "image/images.png";
            form1.Controls.Add(logo);
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}